package com.example.to_dolist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    ListView listViewTasks;
    Button buttonAddTask;
    ArrayList<String> tasks;
    ArrayAdapter<String> adapter;
    SharedPreferences prefs;
    String currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        listViewTasks = findViewById(R.id.listViewTasks);
        buttonAddTask = findViewById(R.id.buttonAddTask);

        prefs = getSharedPreferences("todo_prefs", MODE_PRIVATE);

        // Get logged user
        currentUser = getIntent().getStringExtra("username");
        if (currentUser == null) currentUser = prefs.getString("logged_user", "default");

        // Load tasks for current user
        loadTasks();

        adapter = new ArrayAdapter<>(this, R.layout.task_item, R.id.textViewTask, tasks);
        listViewTasks.setAdapter(adapter);

        buttonAddTask.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            startActivityForResult(intent, 1);
        });

        listViewTasks.setOnItemLongClickListener((parent, view, position, id) -> {
            String task = tasks.get(position);
            tasks.remove(position);
            saveTasks();
            adapter.notifyDataSetChanged();
            Toast.makeText(MainActivity.this, "Deleted: " + task, Toast.LENGTH_SHORT).show();
            return true;
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            String task = data.getStringExtra("task");
            if (task != null && !task.isEmpty()) {
                tasks.add(task);
                saveTasks();
                adapter.notifyDataSetChanged();
            }
        }
    }

    private void loadTasks() {
        Set<String> savedTasks = prefs.getStringSet(currentUser + "_tasks", new HashSet<>());
        tasks = new ArrayList<>(savedTasks);
    }

    private void saveTasks() {
        Set<String> saveSet = new HashSet<>(tasks);
        prefs.edit().putStringSet(currentUser + "_tasks", saveSet).apply();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_logout) {
            prefs.edit().remove("logged_user").apply();
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            finish();
            return true;
        } else if (id == R.id.action_about) {
            startActivity(new Intent(MainActivity.this, AboutActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}




