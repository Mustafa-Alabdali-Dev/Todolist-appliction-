package com.example.to_dolist;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText editUsername, editPassword, editConfirmPassword;
    Button buttonAction;
    TextView toggleText;
    SharedPreferences prefs;
    boolean isSignUpMode = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        prefs = getSharedPreferences("todo_prefs", MODE_PRIVATE);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        editConfirmPassword = findViewById(R.id.editConfirmPassword);
        buttonAction = findViewById(R.id.buttonAction);
        toggleText = findViewById(R.id.toggleText);

        // Auto-login only if logged_user exists
        String loggedUser = prefs.getString("logged_user", null);
        if (loggedUser != null && !loggedUser.isEmpty()) {
            startMainActivity(loggedUser);
        }

        toggleText.setOnClickListener(v -> {
            if (isSignUpMode) {
                isSignUpMode = false;
                editConfirmPassword.setVisibility(View.GONE);
                buttonAction.setText("Login");
                toggleText.setText("Don't have an account? Sign Up");
            } else {
                isSignUpMode = true;
                editConfirmPassword.setVisibility(View.VISIBLE);
                buttonAction.setText("Sign Up");
                toggleText.setText("Already have an account? Login");
            }
        });

        buttonAction.setOnClickListener(v -> {
            String user = editUsername.getText().toString().trim();
            String pass = editPassword.getText().toString().trim();
            String confirmPass = editConfirmPassword.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty() || (isSignUpMode && confirmPass.isEmpty())) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (isSignUpMode) {
                if (!pass.equals(confirmPass)) {
                    Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (prefs.contains(user + "_password")) {
                    Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
                    return;
                }
                prefs.edit().putString(user + "_password", pass).apply();
                Toast.makeText(this, "Sign Up successful! Please login.", Toast.LENGTH_SHORT).show();
                isSignUpMode = false;
                editConfirmPassword.setVisibility(View.GONE);
                buttonAction.setText("Login");
                toggleText.setText("Don't have an account? Sign Up");
                editPassword.setText("");
            } else {
                String savedPass = prefs.getString(user + "_password", null);
                if (savedPass != null && savedPass.equals(pass)) {
                    prefs.edit().putString("logged_user", user).apply();
                    startMainActivity(user);
                } else {
                    Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void startMainActivity(String username) {
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        intent.putExtra("username", username);
        startActivity(intent);
        finish();
    }
}



