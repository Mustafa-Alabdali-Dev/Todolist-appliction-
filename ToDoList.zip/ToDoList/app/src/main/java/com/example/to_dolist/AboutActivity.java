package com.example.to_dolist;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.view.Gravity;

public class AboutActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Simple "About" screen layout
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(40, 40, 40, 40);

        TextView textView = new TextView(this);
        textView.setText("📱 To-Do List App\n\nDeveloped by Mustafa Alabdali\nVersion 1.0\n© 2025");
        textView.setTextSize(18);
        textView.setGravity(Gravity.CENTER);

        layout.addView(textView);
        setContentView(layout);
    }
}

